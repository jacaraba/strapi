'use strict';

/**
 * prueba controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::prueba.prueba');
