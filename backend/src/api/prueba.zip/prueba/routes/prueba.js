'use strict';

/**
 * prueba router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::prueba.prueba');
